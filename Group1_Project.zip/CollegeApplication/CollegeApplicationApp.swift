//
//  CollegeApplicationApp.swift
//  CollegeApplication
//
//  Created by RENHO TSAI on 2024/2/8.
//

import SwiftUI

@main
struct CollegeApplicationApp: App {
    var body: some Scene {
        WindowGroup {
            WelcomeScreenView()
        }
    }
}
