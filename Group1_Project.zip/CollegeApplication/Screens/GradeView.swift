//
//  GradeView.swift
//  CollegeApplication
//
//  Created by 이현성 on 2/11/24.
//

import SwiftUI

struct GradeView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    GradeView()
}
