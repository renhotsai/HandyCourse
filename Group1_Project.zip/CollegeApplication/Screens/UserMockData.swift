//
//  UserMockData.swift
//  CollegeApplication
//
//  Created by RENHO TSAI on 2024/2/9.
//

import Foundation

var users : [User] = [
//    Instructor(name: "Jeremy", username: "jeremy", password: "jeremy"),
    Instructor(name: "Hyun", username: "hyun", password: "hyun", email: "devhyun05@gmail.com", address: "83 greenwin village rd", phoneNumber: "437-223-7368", imageName: "hyun-image"),
//    Instructor(name: "Aman", username: "aman", password: "aman"),
//    Student(name: "Jack", username: "jack", password: "jack"),
//    Student(name: "Mike", username: "mike", password: "mike"),
    Student(name: "Amy", username: "amy", password: "amy",email: "amy@gmail.com",address: "30 Kennedy Rd.",phoneNumber: "234-423-1234",imageName: "hyun-image"),
    Student(name: "John", username: "john", password: "john",email: "john@gmail.com",address: "30 Kennedy Rd.",phoneNumber: "234-423-1234")
]
